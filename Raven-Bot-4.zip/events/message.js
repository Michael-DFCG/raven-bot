module.exports = {
	name: 'message',
	execute(message) {
		
	},
};