module.exports = {
	name: 'ready',
	once: true,
	execute(client, message) {
	  
	  
		console.log(`${client.user.tag} è online!`);
	},
};