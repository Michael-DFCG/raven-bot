const db = require('./../../Schema/WarnSchema')
const Discord = require('discord.js')
//leggi ds 

module.exports = {
    name : 'remove-all-warns', // delwarns meglio?
    description: "rimuovere gli warn",
    aliases: ["delwarns"],//mettili dopo la virgola i nomi che vuoi
	  async execute(message, args) {
      if(user.id == message.author.id) {
        message.reply("Non puoi levare i warn ad te stesso")
      }
        if(!message.member.hasPermission('MANAGE_MESSAGES')) return message.channel.send('Non hai il permesso di utalizzare questo comando.')
        const user = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
        if(!user) return message.channel.send('Utente non valido')
        db.findOne({ guildid : message.guild.id, user: user.user.id}, async(err,Data) => {
            if(err) throw err;
            if(Data) {
                let number = parseInt(args[1]) - 1
                Data.content.splice(number, 1)
                message.channel.send('Warn eliminato')
                Data.save()
            } else {
                message.channel.send('Questo utente non ha nessun warn in questo server!')
            }
        })
    }
}