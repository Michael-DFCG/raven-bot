const db = require('./../../Schema/WarnSchema')
const { Message, MessageEmbed } = require('discord.js')
const Discord = require('discord.js')


module.exports = {
    name :'warns',
	  async execute(message, args) {
        const user = message.mentions.members.first() || message.guild.members.cache.get(args[0])
        if(!user) return message.channel.send('Utente non valido.')
        const reason = args.slice(1).join(" ")
        db.findOne({ guildid: message.guild.id, user: user.user.id}, async(err, Data) => {
            if(err) throw err;
            if(Data) {
                message.channel.send(new MessageEmbed()
                    .setTitle(`${user.user.tag} warns`)
                    .setDescription(
                        Data.content.map(
                            (w, i) => 
                            `\`${i + 1}\` | Moderatore : ${message.guild.members.cache.get(w.moderator).user.tag}\n Motivazione : ${w.reason}`
                    ))
                    .setColor("BLUE")
                )
            } else {
                message.channel.send("L'utente non ha ricevuto nessun warn.")
            }

        })
    }
}