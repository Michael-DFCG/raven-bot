const db = require('./../../Schema/WarnSchema')
const Discord = require('discord.js')

module.exports = {
    name : 'remove-warn',
    async execute(message, args, bot){
        if(!message.member.hasPermission('MANAGE_MESSAGES')) return 
        new Discord.MessageEmbed()
        .setTitle('Errore')
        .setDescription('Non hai il permesso di utalizzare questo comando.')
        const user = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
        if(!user) return message.channel.send('Utente non valido')
        db.findOne({ guildid : message.guild.id, user: user.user.id}, async(err,Data) => {
            if(err) throw err;
            if(Data) {
                let number = parseInt(args[1]) - 1
                Data.content.splice(number, 1)
                message.channel.send('Warn eliminato')
                Data.save()
            } else {
                message.channel.send('Questo utente non ha nessun warn in questo server!')
            }
        })
    }
}