const db = require('./../../Schema/WarnSchema')
const { Message, MessageEmbed } = require('discord.js')
const Discord = require('discord.js')

module.exports = {
    name: 'warn',
    description: 'Warna un utente', // virgola
	  execute(message, args) {
        if(!message.member.hasPermission('MANAGE_MESSAGES')) { return 
        message.reply('Non hai il permesso di utilizzare questo comando.') 
        
        new Discord.MessageEmbed()
        .setTitle(":x: |") // ho capito bene sistemato
        .setTitle("warn")
        
        const user = message.mentions.members.first() || message.guild.members.cache.get(args[0])
        if(!user) return message.channel.send('Utente non valido.')
        const reason = args.slice(1).join(" ")
        db.findOne({ guildid: message.guild.id, user: user.user.id}, async(err, Data) => {
            if(err) throw err;
            if(!Data) {
                Data = new db({
                    guildid: message.guild.id,
                    user : user.user.id,
                    content : [
                        {
                            moderator : message.author.id,
                            reason : reason
                        }
                    ]
                })
            } else {
                const obj = {
                    moderatore: message.author.id,
                    motivazione : reason
                }
                Data.content.push(obj)
            }
            Data.save()
        });

        if(!reason) return message.reply("Inserisci un motivo per warnare l'utente")
        user.send(new MessageEmbed()
            .setDescription(`Sei stato zu ${message.guild.name}`)
            .addField(`Motivazione` , `${reason}`)
            .addField("Moderatore", message.author)
            .setColor("RANDOM")
        )
        message.channel.send(new MessageEmbed()
            .setTitle("Utente warnato!")
            .addField("Utente:", user)
            .addField("Motivazione:", `${reason}`)
            .addField("Moderatore:", message.author)
            .setColor('RANDOM')
            .setFooter("Orario").setTimestamp()
        )
    }
        }}