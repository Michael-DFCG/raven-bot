module.exports = {
  name: 'lol',
  execute (message, args) {
    const Discord = require('discord.js')
    const client = new Discord.Client()
    const disbut = require('discord-buttons')
  
    
}  
}