const Discord = require("discord.js");
module.exports = {
	name: 'afk',
	description: 'mostra avatar',
	execute(message, args) {
	  
	   
	    
	}
}