const Discord = require("discord.js");
module.exports = {
	name: 'spegni',
	description: 'etta bulmuka',
	onlyGuild: true,
	execute(message, args) {
	  // posso startare un attimo?
    if (message.author.id !== '852966041780092988') {
      let solodev = new Discord.MessageEmbed()
      .setTitle("<:RvE_crocetta:819549207693754378> | Solo Developers")
      .setDescription("Questo comando è riservato ai developers del bot")
      .setColor("RED")
      return message.channel.send(solodev)
      message.delete()
    } else {
    
    let spegnimento = new Discord.MessageEmbed()
    .setTitle("<:RvE_verifica:819507152896917544> | Spegnimento in corso")
    .setDescription("Spegnimento tra 3...")
    .setColor("YELLOW")
    let spegnimento2 = new Discord.MessageEmbed()
    .setTitle("<:RvE_verifica:819507152896917544> | Spegnimento in corso")
    .setDescription("Spegnimento tra 2...")
    .setColor("YELLOW")
    let spegnimento3 = new Discord.MessageEmbed()
    .setTitle("<:RvE_verifica:819507152896917544> | Spegnimento in corso")
    .setDescription("Spegnimento tra 1...")
    .setColor("YELLOW")
    let spento = new Discord.MessageEmbed()
    .setTitle("<:RvE_verifica:819507152896917544> | Bot Spento")
    .setDescription("Il bot è stato spento correttamente")
    .setColor("GREEN")
    return message.channel.send(spegnimento)
    .then((message)=> {
      setTimeout(function(){
        message.edit(spegnimento2);
      }, 1000)
      setTimeout(function(){
        message.edit(spegnimento2);
      }, 2000)
      setTimeout(function(){
        message.edit(spegnimento3);
      }, 3000)
      setTimeout(function(){
        message.edit(spegnimento3);
      }, 4000)
      setTimeout(function(){
        message.edit(spento);
      }, 5000)
      setTimeout(function(){
        process.exit()
      }, 7000)
    })
    }
  }
  }