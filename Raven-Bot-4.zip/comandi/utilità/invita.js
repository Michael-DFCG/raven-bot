const Discord = require('discord.js');
module.exports = {
	name: 'invito',
	description: 'invita il bot',
	aliases: ["ui"],
	execute(message, args) {
	  const invito = new Discord.MessageEmbed()
	  .setTitle("invito")
	  .addFields(
	    { name: "<:dev:868036023739879505> link per invitarmi", value: "[clicca](https://discord.com/oauth2/authorize?client_id=863020585838837771&scope=bot&permissions=8)"},
	    { name: "<:verificato:868035330517921813> server ufficiale", value: "[clicca](https://discord.gg/rve)"},
	    { name: "`❔`server di supporto", value: "[clicca](https://discord.gg/Eh6zE6Prde)"}
	    )
	    message.lineReplyNoMention(invito)
	}
}