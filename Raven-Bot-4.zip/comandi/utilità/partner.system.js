const Discord = require('discord.js');
const talkedRecently = new Set();
module.exports = {
	name: 'partner',
	async execute(message, args) {
		if (talkedRecently.has(message.author.id)) {
			let aspetta = new Discord.MessageEmbed()
				.setTitle('Aspetta 1 minuto per eseguire un altra partnership')
				.setColor('RED');
			return message.channel.send(aspetta);
		} else {
			// questa roba dello slowmode togliere?
			const utente = message.mentions.users.first();
			const raven = await message.client.channels.cache.get(
				'860485925153669131'
			);
			const chaos = await message.client.channels.cache.get(
				'769624028607414363'
			);
			const darling = await message.client.channels.cache.get(
				'773681395024920586'
			);
			const msg = args.slice(1).join(' ');
			const norole = new Discord.MessageEmbed()
				.setTitle(':x: | Non sei un gestore partnership')
				.setColor('RED');
			//RAVEN

			if (message.member.roles.cache.has('822157252672225341'))
				if (message.member.roles.cache.has('871462103251320872'))
					if (message.member.roles.cache.has('802885632514326578'))
			if (!utente) {
				let noutente = new Discord.MessageEmbed()
					.setTitle(
						":x: | Inserisci l'utente con cui vuoi effettuare la partnership"
					)
					.setColor('RED');
				return message.channel.send(noutente);
			}
			if (!msg) {
				let nodescrizione = new Discord.MessageEmbed()
					.setTitle(
						':x: | Inserisci la descrizione del server con cui vuoi effettuare la partnership'
					)
					.setColor('RED');
				return message.channel.send(nodescrizione);
			}
			/*
      if (utente.id == message.author.id) {
        let antisestessi = new Discord.MessageEmbed()
        .setTitle(":x: | Non puoi eseguire partnership con te stesso")
        .setColor("RED")
        return message.channel.send(antisestessi);
      }
    */
			 message.delete()
			//INVIO
			raven.send(
				msg +
					'\n========================================\nEffettuata con: <@' +
					utente.id +
					'>\n========================================\nAddetto: <@' +
					message.author.id +
					'>'
			);
			chaos.send(
				msg +
					'\n========================================\nEffettuata con: <@' +
					utente.id +
					'>\n========================================\nAddetto: <@' +
					message.author.id +
					'>' +
					`\n<@&778134709401813003>`
			);
			 darling.send(msg + "\n========================================\nEffettuata con: <@" + utente.id+">\n========================================\nAddetto: <@" + message.author.id + ">")

			let eseguita = new Discord.MessageEmbed()
				.setTitle('Partnership eseguita!')
				.setDescription(
					`<@${message.author.id}> ` +
						`hai effettuato una partnership correttamente!`
				)
				.setColor('GREEN');
			message.channel.send(eseguita);
			/*
                .then(msg => {
                message.delete({ timeout: 4000 })
                */
			let eseguitadmuser = new Discord.MessageEmbed()
				.setTitle('<:Partner:833337847330111518> | Partnership Eseguita!')
				.setDescription(
					'Grazie per aver effettuato una partnership con [RAVEN EMPIRE](https://discord.gg/rve), [CHAOS EMPIRE](https://discord.gg/jmQax5sptt)'
				)
				.setColor('BLUE');
			utente.send(eseguitadmuser);
			talkedRecently.add(message.author.id);
			setTimeout(() => {
				talkedRecently.delete(message.author.id);
			}, 60000);
		}

  }
	//console.log(error) } //mah è strasbagliato mettilo non davanti ame
	//NON VA
};
