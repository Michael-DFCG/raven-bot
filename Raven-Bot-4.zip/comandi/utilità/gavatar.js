const Discord = require("discord.js");
module.exports = {
	name: 'gavatar',
	description: 'mostra avatar in gif',
	execute(message, args) {
	    const h = new Discord.MessageEmbed()
  .setDescription("Fai `avatar` per quella in png")
  .setImage("https://cdn.discordapp.com/avatars/"+message.author.id+"/"+message.author.avatar+".gif")
  message.reply(h)
	   
	}
}