const Discord = require("discord.js");
module.exports = {
	name: 'eval',
	description: 'mostra avatar in gif',
	execute(message) {
	    const args = message.content.split(" ").slice(1);
	    const config = require('../../config.json')
	    function clean(text) {
  if (typeof(text) === "string")
    return text.replace(/`/g, "`" + String.fromCharCode(8203)).replace(/@/g, "@" + String.fromCharCode(8203));
  else
      return text;
}
    if(message.author.id !== config.ownerID) return;
    try {
      const code = args.join(" ");
      let evaled = eval(code);
      let util = require('util')
      if (typeof evaled !== "string")
        evaled = require("util").inspect(evaled);
        var embed = new Discord.MessageEmbed()
        .setTitle("eval")
        .setDescription("Ricevuto\n\`\`\`js\n"+code+`\n\`\`\``)
        message.channel.send(clean(evaled), {code})
      message.channel.send(embed);
    } catch (err) {
      message.channel.send(`\`ERROR\` \`\`\`js\n${err}\n\`\`\``);
    }
  }
}