const Discord = require('discord.js');
module.exports = {
	name: 'serverinfo',
	description: 'informazioni su questo server',
	onlyGuild: true,
	execute(message, args) {
	  var server = message.guild;

        var botCount = server.members.cache.filter(member => member.user.bot).size;
        var utentiCount = server.memberCount - botCount;
        var owner = message.guild
        var categoryCount = server.channels.cache.filter(c => c.type == "category").size
        var textCount = server.channels.cache.filter(c => c.type == "text").size
        var voiceCount = server.channels.cache.filter(c => c.type == "voice").size
        var embed = new Discord.MessageEmbed()
            .setTitle(server.name)
            .setDescription("Tutte le info su questo server")
            .setThumbnail(server.iconURL())
            .setColor('BLURPLE')
            .addField("<:owner:866990538199662592> Owner", "<@!" + server.ownerID + ">")
            .addField("`🆔` Server id", server.id)
            .addField("Regione del server", server.region)
            .addField("`👤` Membri", server.memberCount)
            .addField("Canali", "<:categoria:866996610096562176> Categorie: " + categoryCount + " - <:Testuale:866989293801046038> Testuali: " + textCount + " - <:Vocale:866989663025233950> Vocali: " + voiceCount, true)
            .addField("Server creato il", server.createdAt.toDateString(), true)
            .addField("Boosts", "<a:Boost:866991358794661889> " + server.premiumSubscriptionCount + " boosts", true)

        message.lineReplyNoMention(embed)

    }
}