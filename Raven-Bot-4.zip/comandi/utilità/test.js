const Discord = require('discord.js');
const paginationEmbed = require('discord.js-pagination');
 
module.exports = {
	name: 'test',
	description: 'i',
	aliases: [],
	execute(message, args) { 
        
    const embed1 = new Discord.MessageEmbed()
    .setTitle("embed1")
    const embed2 = new Discord.MessageEmbed()
    .setTitle("embed2")

// Create an array of embeds
    pages = [
    embed1,
    embed2,
];
paginationEmbed(message, pages);
// first 2 args are required
}
}   