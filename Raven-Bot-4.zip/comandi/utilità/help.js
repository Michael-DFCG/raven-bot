const Discord = require('discord.js');
const paginationEmbed = require('discord.js-pagination');
 
module.exports = {
	name: 'help',
	description: 'i',
	aliases: [],
	execute(message, args) { 
        
    const embed1 = new Discord.MessageEmbed()
    .setTitle("home")
    .addFields(
      { name: "`🏡` Home page", value: "pagina 1"},
      { name: "<a:divertimento:868037350243049492> Divertimento", value: "pagina 2"},
      { name: "`🤖` Utilità", value: "pagina 3"},
      { name: "<:cartella:869484529759432734> Info & Setup", value: "pagina 4"},
      { name: "<:moderazione:868037857011441735> Moderazione", value: "pagina 5"},
    )
    
    const embed2 = new Discord.MessageEmbed()
    .setTitle("Divertimento")
    .setDescription("`8ball | hackera | uccidi | rickastley | gayrate | pp | errore | say | spegni`")
    const embed3 = new Discord.MessageEmbed()
    .setTitle("Utilità")
    .setDescription("`avatar/gavatar | serverinfo | userinfo | help | voto | suggerisci`")
    const embed4 = new Discord.MessageEmbed()
    .setTitle("Info & Setup")
    .setDescription("`botinfo | invito | ping | setup`")
    const embed5 = new Discord.MessageEmbed()
    .setTitle("Moderazione")
    .setDescription("`mute | unmute | purge | lock | unlock | slowmode`")
    
// Create an array of embeds
    pages = [
    embed1,
    embed2,
    embed3,
    embed4,
    embed5,
    ];
paginationEmbed(message, pages);
// first 2 args are required
}
}   
