const Discord = require('discord.js');
const client = new Discord.Client()
module.exports = {
	name: 'botinfo',
	description: 'informazioni sul bot',
	execute(message, args) {
	  let totalUsers = message.client.guilds.cache.reduce((acc, value) => acc + value.memberCount, 0)
    let totalS = message.client.guilds.cache.size;
    let Node = process.version;
	  const botinfo = new Discord.MessageEmbed()
    .setColor('BLACK')
    .setTitle("bot info")
    .addFields(
      { name: " <:NodeJS:866989089709883406> Linguaggio", value: "JavaScript / Node.js"},
      { name: " <:djs:866990085526650890> Versione", value: "Node.js: " + Node + "\nDiscord.js: 12.5.3"},
      { name: "<:verificato:868035330517921813> Versione Bot", value: "v1.1.8"},
      { name: "`👥` Utenti totali", value: `${totalUsers}`},
      { name: "`🏘️` Servers Totali", value: `${totalS}`},
      { name: "<:owner:866990538199662592> Owner", value: "OnlyMichael#0001\n[RvE] D4rkkSonic#4476"},
      { name: "<:dev:868036023739879505> Head Developer", value: "OnlyMichael#0001"},
      { name: "`💻` Developer", value: "[RvE] D4rkkSonic#4476\n[RvE] [NOVA] AlaaAlibi_02#0001\nfеdе0009000#6669\nFrancy#1400"}
      );
    message.lineReplyNoMention(botinfo);
  }
}