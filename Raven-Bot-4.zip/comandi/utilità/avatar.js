const Discord = require("discord.js");
module.exports = {
	name: 'avatar',
	description: 'mostra avatar',
	execute(message, args) {
	  
	    const h = new Discord.MessageEmbed()
  .setDescription("Fai `gavatar` per quella in gif")
  .setImage("https://cdn.discordapp.com/avatars/"+message.author.id+"/"+message.author.avatar+".png")
  message.reply(h)
	    
	}
}