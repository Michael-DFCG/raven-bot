const discord = require("discord.js");
const weather = require('weather-js');
module.exports = {
	name: 'meteo',
	description: 'pong!',
	execute(message, args) {
	  weather.find({search: args.join(" "), degreeType: 'C'}, function(err, result) {
	    if(!args[0]) {
	      let nopaese = new Discord.MessageEmbed()
        .setTitle(":x: | Inserisci un paese")
        .setDescription("Devi prima inserire un paese")
        .setColor("RED")
        message.channel.send(nopaese) 
	    } else {
	      try {
let embed = new discord.MessageEmbed()
.setTitle(`Tempo Atmosferico - ${result[0].location.name}`)
.setColor("#ff2050")
.addField("Temperatura", `${result[0].current.temperature}°`, true)
.addField("Cielo", result[0].current.skytext, true)
.addField("Umidità", result[0].current.humidity, true)
.addField("Velocità del vento", result[0].current.windspeed, true)//What about image
.addField("Tempo di osservazione", result[0].current.observationtime, true)
.addField("Visualizzazione del vento", result[0].current.winddisplay, true)
.setThumbnail(result[0].current.imageUrl);
   message.channel.send(embed)
} catch(err) {
  let noresult = new discord.MessageEmbed()
  .setTitle(":x: | Nessun Risultato")
  .setDescription("Non ho trovato nessun risultato in base al paese inserito")
  .setColor("RED")
  return message.reply(noresult)
}
}
})
}
}