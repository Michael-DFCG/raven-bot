const Discord = require("discord.js");
module.exports = {
	name: 'lista-servers',
	description: 'mostra avatar in gif',
	execute(client, message) {
	    
	    const config = require('../../config.json')
	    var guild = message.client.guilds.cache.map(g=>g.name).join('\n')
	   message.channel.send(`\`\`\`\n${guild}\n\`\`\``)
	}
}