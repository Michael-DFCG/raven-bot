const Discord = require("discord.js");
const talkedRecently = new Set();
module.exports = {
	name: 'compitodev',
	description: 'Assegna un compito a un developer',
	async execute(message, args, client, channels) { //LASCIA ok ma da errore lo so sto scrivendo il codiil  è ovvio che non va ○○
    if (!message.member.roles.cache.has("871311014526873600")) {
      return;
    } else {
    if (talkedRecently.has(message.author.id)) {
            let antispam = new Discord.MessageEmbed()
            .setTitle("Protezione Anti Spam")
            .setDescription("Puoi assegnare un compito ogni minuto")
            .setColor("RED")
            return message.channel.send(antispam);
    } else {
    const utente = message.mentions.users.first()
    const titolo = args[1]
    const compito = args.slice(1).join(" ") // spe dovrebbe darmi azzurro ma no
    if (!utente) {
      let noutente = new Discord.MessageEmbed()
      .setTitle(":x: | Inserisci l'utente a cui assegnare il compito")
      .setColor("RED")
      return message.channel.send(noutente);
    }
    if (!titolo) {
      let notitolo = new Discord.MessageEmbed()
      .setTitle(":x: | Inserisci il titolo del compito")
      .setColor("RED")
      return message.channel.send(notitolo)
    }
    if (!compito) {
      let nocompito = new Discord.MessageEmbed()
      .setTitle(":x: | Inserisci il compito")
      .setColor("RED")
      return message.channel.send(nocompito)
    }
      let canalecompiti = message.guild.channels.cache.get("871129860540624946")
      canalecompiti.send(`**Nuovo compito**\n\n**Compito:** ${compito}\n**Per:** ${utente}\n**Assegnato da:** ${message.author}`)
      let compitoassegnato = new Discord.MessageEmbed()
      .setTitle("Ti è stato assegnato un compito!")
      .setDescription(`\n\n**Compito:** ${compito}\n**Assegnato da:** ${message.author}`)
      .setColor("RANDOM")
      utente.send(compitoassegnato)
      //
    }
    talkedRecently.add(message.author.id);
        setTimeout(() => {
          talkedRecently.delete(message.author.id);
        }, 60000);
    }
  }
  } // chiudi tutto ricordati!