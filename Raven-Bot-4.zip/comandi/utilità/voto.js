const Discord = require('discord.js');
const client = new Discord.Client()
const PBapi = require('prime-bots.js')
const PrimeBot = new PBapi('APIToken.gteicak4qqc.iu62twzgf2b', client);

module.exports = {
	name: 'voto',
	description: 'voti di PrimeBots',
	aliases: [],
	async execute(message, args) {
	  let utentePong = message.mentions.members.first() || message.author; {
	  let utente = message.author.id
	  let haVotato = await PrimeBot.hasVoted(utente);
	  let voti = await PrimeBot.getVotes(); {
	    if (haVotato = false) {
	      haVotato = "No"
	      } else {
	        "Sì"
	      }
	  }
	  const voto = new Discord.MessageEmbed()
	  .setTitle("PrimeBots: votazioni")
	  .setDescription("l'utente <@" + utentePong + "> ha votato? " + haVotato ? "Sì" : "No"+"\n[clicca](https://primebots.it/bots/863020585838837771) per votarmi")
	   message.channel.send(voto)
	}
	}
}