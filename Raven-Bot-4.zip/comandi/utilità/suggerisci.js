const Discord = require("discord.js");
const talkedRecently = new Set();
module.exports = {
	name: 'suggerisci',
	description: 'suggerisci',
	onlyGuild: true,
	async execute(message, args, client, channels) {
    if (talkedRecently.has(message.author.id)) {
            let incooldown = new Discord.MessageEmbed()
            .setDescription("<a:RvE_migiranolepalle:853601990403424276> | Puoi usare questo comando ogni 5 minuti")
            .setTimestamp()
            .setColor("RED")
            message.channel.send(incooldown)
    } else {
let embed1 = new Discord.MessageEmbed()
.setColor("RED")
.setDescription("Devi inserire qualcosa da suggerire!")

let msg = args.slice(0).join(" ")
if(!msg) {
	return message.channel.send(embed1)
}
let canale = await message.client.channels.cache.get("869226841813172304");
let embed2 = new Discord.MessageEmbed()
.setColor("BLUE")
.addField("Nuovo Suggerimento", msg)
.setFooter(`Suggerito da ` + message.author.tag + ` (` + message.author + `)`)
.setTimestamp()

canale.send(embed2).then(msg => {
                msg.react('819549183404933121')
                msg.react('819549207693754378')
                message.delete({ timeout: 1000 })
	let inviato = new Discord.MessageEmbed()
  .setTitle("\<:spunta:869124074255810580> |  uggerimento inviato!")
  .setDescription("Il tuo suggerimento è stato inviato!\n")
  .setTimestamp()
  .setFooter(`Grazie per il tuo suggerimento ` + message.author.username + `!`)
  message.channel.send(inviato)
        talkedRecently.add(message.author.id);
        setTimeout(() => {
          talkedRecently.delete(message.author.id);
        }, 300000);
})
  }
}
}