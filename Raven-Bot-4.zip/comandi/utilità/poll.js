const Discord = require('discord.js')
module.exports = {
	name: 'poll',
	execute(message, args) {
	  var messageArray = message.content.split(' ');
        var messageargs = messageArray.slice(2);
        var domanda = messageargs.join(' ');

	  
	  const canale = message.mentions.channels.first()
	  const nocan = new Discord.MessageEmbed()
	  .setTitle(":x: | Menziona un canale")
	  .setDescription("per favore menziona un canale")
	  const nopoll = new Discord.MessageEmbed()
	  .setTitle(":x: | Inserisci qualcosa")
	  .setDescription("per favore scrivi qualcosa da mettere per il sondaggio")
	  if(!canale) {
	    return message.channel.send(nocan)
	  }
	  if(!domanda) {
	    return message.channel.send(nopoll)
	  }
	  
	  const poll = new Discord.MessageEmbed()
	  .setTitle("sondaggio")
	  .setDescription(domanda)
	  .setFooter("semplici sondaggi")
	  canale.send(poll).then(msg => {
                msg.react('819549183404933121')
                msg.react('819549207693754378')
	  })
}
}