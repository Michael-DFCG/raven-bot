const Discord = require("discord.js");
module.exports = {
	name: '.',
	description: 'mostra avatar in gif',
	execute(message, args) {
	return;
	}
}