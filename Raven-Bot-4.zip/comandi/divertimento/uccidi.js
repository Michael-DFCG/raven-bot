const Discord = require("discord.js");
module.exports = {
	name: 'uccidi',
	description: 'uccidi un utente',
	onlyGuild: true,
	execute(message, args) {
	  const taggedUser = message.mentions.users.first();
    var messaggi = [`${taggedUser} ha chiamato la polizia. \npiano fallito.`, `${taggedUser} é caduto in un tombino\n hai vinto!`, "cosa fai non hai un arma", "cosa fai non hai le ricariche per la pistola", `hai ucciso ${taggedUser} con una mazza.\nhai vinto!`, `hai ucciso ${taggedUser} con una pistola.\nhai vinto!`]
    if (!taggedUser) {
      message.reply('tagga qualcuno')
    }
      var random = Math.floor(Math.random() * messaggi.length);
      message.channel.send(messaggi[random]);
  }
}