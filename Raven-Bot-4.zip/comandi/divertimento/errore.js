const Discord = require("discord.js");
module.exports = {
	name: 'errore',
	description: 'GET RICKROLLED LOL',
	onlyGuild: true,
	execute(message, args) {
	  var sp = new Discord.MessageEmbed()
      .setImage("https://media0.giphy.com/media/Vu7FU5T4RJPo1esgna/giphy.gif?cid=6c09b95239596bc359ef8281185cc4f69b5ebb363ab80c20&rid=giphy.gif&ct=g")
      message.channel.send("RIP", sp)
	}
}