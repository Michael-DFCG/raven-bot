const Discord = require("discord.js");
module.exports = {
	name: 'gayrate',
	description: 'gae',
	execute(message, args) {
	  const taggedUser = message.mentions.users.first() || message.author;
    function makeid(length) {
    var result           = '';
    var characters       = '1234567890';
    var charactersLength = characters.length;
    for ( var i = 0; i < length; i++ ) {
      result += characters.charAt(Math.floor(Math.random() * 
 charactersLength));
   }
   return result;
}
var messaggi = ["1", "2", "3", "4", "5", "6","7","8","9",makeid(2),makeid(2),makeid(2),makeid(2),makeid(2),makeid(2),makeid(2),makeid(2),makeid(2),makeid(2)]
var random = Math.floor(Math.random() * messaggi.length);
      let gay = new Discord.MessageEmbed()
      .setTitle("Gay Calculator")
      .setDescription("Caricamento...");
      let gayfatto = new Discord.MessageEmbed()
     .setTitle("Gay Calculator")
     .setDescription("<@"+taggedUser+">"+` è ` + random + `% gay`)
    .setColor("RANDOM")
      message.channel.send(gay)
     .then(msg => {  
      setTimeout(function() {
  msg.edit(gayfatto)
 }, 2000);
     })

      //message.channel.send(`${taggedUser}: ` + messaggi[random]);
  }
}