const Discord = require("discord.js");
module.exports = {
	name: 'pp',
	description: 'heehhehhe',
	execute(message, args) {
	  var messaggi = ["=", "==", "===", "====", "=====", "======", "=======", "========", "========="]
	  var random = Math.floor(Math.random() * messaggi.length);
	  var pp = new Discord.MessageEmbed()
	  .setTitle("Lunghezza")
	  .setDescription("8"+messaggi[random]+"D")
    .setColor("RANDOM")
        message.channel.send(pp);
  }
}