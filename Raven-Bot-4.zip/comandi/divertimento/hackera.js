const Discord = require("discord.js");
module.exports = {
	name: 'hackera',
	description: 'hackera un utente per finta',
	onlyGuild: true,
	execute(message, args) {
	  const taggedUser = message.mentions.users.first();
    var messaggi = ["20.19.39.299", "109.29:29.29","206.29.28:39", "208:29.39.255", "255:265.299.09", "299.39:31:06"]
    var random = Math.floor(Math.random() * messaggi.length);
    if (!taggedUser) {
      let nouser = new Discord.MessageEmbed()
      .setTitle(":x: | Inserisci un utente")
      .setDescription("Devi inserire un utente da hackerare")
      .setColor("RED")
      message.reply(nouser)
    } else {
    message.channel.send(`Sto hackerando ${taggedUser}`)
    .then((msg)=> {
      setTimeout(function(){
        msg.edit(`Bypassing 2FA`);
      }, 4000)
      setTimeout(function(){
        msg.edit(`IP: ` + messaggi[random])
      }, 7000)
      setTimeout(function(){
        msg.edit(`Sto segnalando ${taggedUser}`)
      }, 9000)
      setTimeout(function(){
        msg.edit(`${taggedUser} è stato Segnalato alla Polizia`)
      }, 12000)
      setTimeout(function(){
        msg.edit(`${taggedUser} è stato Hackerato!`)
      }, 15000)
    })
	}
}
}