const Discord = require("discord.js");
module.exports = {
	name: '8ball',
	description: '🎱',
	execute(message, args) {
    var messageArray = message.content.split(' ');
		var messageargs = messageArray.slice(1);
		var domanda = messageargs.join(' ');
    if(!domanda) {
let nodomanda = new Discord.MessageEmbed()
.setTitle(":x: | Inserisci una domanda")
.setDescription("Devi inserire una domanda")
.setColor("RED")
return message.channel.send(nodomanda)
    }
    var messaggi = ["ma certo", "no", "senti, non farmi domande del genere", "perchè non vai a... hai capito", "parlo 2 lingue lo sapevi? JavaScript e Node.js 🤣 (la tua domanda non ha senso)", "cosa dici?"]
    var random = Math.floor(Math.random() * messaggi.length);
        let response = new Discord.MessageEmbed()
        .setTitle("8ball - La palla magica")
        .addFields(
          { name: "Domanda:", value:  domanda },
          { name: "Risposta:", value: messaggi[random]}
          )
        .setColor("GREEN")
        message.channel.send(response);
  }
}