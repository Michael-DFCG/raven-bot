const Discord = require("discord.js");
require('discord-reply');
module.exports = {
	name: 'reply',
	description: 'mostra avatar in gif',
	execute(message, args) {
	  message.lineReply('ho risposto')
	   
	}
}