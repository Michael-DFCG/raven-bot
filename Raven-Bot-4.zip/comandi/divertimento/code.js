const Discord = require('discord.js');
module.exports = {
	name: 'codice',
	description: 'i',
	aliases: [],
	execute(message, args) { 
        var messageArray = message.content.split(' ');
        var messageargs = messageArray.slice(1);
        var say = messageargs.join(' ');

        let InvalidSay = new Discord.MessageEmbed()
            .setColor('RANDOM')
            .setTitle('Comando Incompleto')
            .setDescription(
                message.author.toString() +
                    ' Devi digitare un messaggio valido dopo il comando!'
            );
        if (!say) return message.channel.send(InvalidSay)
         
   let cleanedContent = message.content.replace('@', ''); // if you want to replace the @

        message.channel.send("```\n"+say+"\n```");
        message.delete({ timeout: 0000 });
    }
  
}