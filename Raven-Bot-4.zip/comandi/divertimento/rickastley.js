const Discord = require("discord.js");
module.exports = {
	name: 'rickastley',
	description: 'GET RICKROLLED LOL',
	onlyGuild: true,
	execute(message, args) {
	  var sp = new Discord.MessageEmbed()
      .setImage("https://raw.githubusercontent.com/Michael-DFCG/rickastley/main/tenor.gif")
      message.channel.send("Never Gonna Give You Up", sp)
	}
}