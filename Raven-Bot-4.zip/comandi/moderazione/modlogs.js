const Discord = require('discord.js')
module.exports = {
	name: 'setup',
	description: 'tutte le logs',
	onlyGuild: true,
	async execute(message, args) {
	  if (!message.member.hasPermission("MANAGE_SERVER")) {
	  let noperm = new Discord.MessageEmbed()
    .setTitle(":x: | Permessi Mancanti")
    .setColor("RED")
    .setDescription(`E' necessario il permesso "GESTISCI SERVER".`)

      message.channel.send(noperm)
	  } else {
        let channel = message.guild.channels.cache.find(channel => channel.name == "raven-logs");
	  if (!channel) {
	    message.guild.channels.create('raven-logs', {
	      type: 'text',
	      permissionOverwrites: [
	        {
			id: message.guild.id,
			deny: ['VIEW_CHANNEL'],
	        },
	    ],
	    }).then(c => {
	      let channelcreated = new Discord.MessageEmbed()
        .setTitle("<:spunta:869124074255810580> | Canale creato")
        .setDescription("Il canale per i logs è stato creato")
        .setColor("BLUE")
        c.send(channelcreated)
	    })
	  } else {
	    let logsce = new Discord.MessageEmbed()
      .setTitle(":x: | Canale già esistente")
      .setDescription("Il canale raven-logs esiste già")
      .setColor("RED")
      message.channel.send(logsce)
	  }
      
    }
}
  
}