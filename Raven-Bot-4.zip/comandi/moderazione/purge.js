const Discord = require('discord.js');
module.exports = {
	name: 'purge',
	description: 'elimina x messaggi',
	aliases: ["ui"],
	execute(message, args) {
	  if (!message.member.hasPermission('MANAGE_MESSAGES')) {
	  let noperm = new Discord.MessageEmbed()
    .setTitle(":x: | Permessi Mancanti")
    .setDescription(`E' necessario il permesso "GESTISCI MESSAGGI".`)
    .setColor("RED")
      message.channel.send(noperm)
		} else {
      var count = message.content.slice(7); //Ottenere il numero inserito dall'utente
		count = parseInt(count);

		if (!count) {
			let nocount = new Discord.MessageEmbed()
      .setTitle(":x: | Inserisci un numero")
      .setDescription("Devi inserire un numero")
      .setColor("RED")
      message.channel.send(nocount);
		} else {
message.delete()
		message.channel.bulkDelete(count, true);
		let deleted = new Discord.MessageEmbed()
    .setTitle("<:RvE_verifica:819507152896917544> | Messaggi Eliminati")
    .addField("Moderatore:", `<@${message.author.id}>`)
    .addField("Messaggi:", count)
    .setColor("RED")
    message.channel
			.send(deleted)
			.then(msg => {
				msg.delete({ timeout: 1000 });
			})
		}
	}
  }
}