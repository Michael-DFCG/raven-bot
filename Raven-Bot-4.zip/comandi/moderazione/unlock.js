const Discord = require('discord.js')
module.exports = {
	name: 'unlock',
	description: 'Sblocca un canale',
	onlyGuild: true,
	async execute(message, args) {
if (!message.member.hasPermission('MANAGE_CHANNELS')) { 
        let nopermessi = new Discord.MessageEmbed()
        .setDescription(":x: | Hai bisogno del permesso \"GESTISCI CANALI\" per usare questo comando")
        .setColor("RED")
        message.channel.send(nopermessi)
        } else {
      message.channel.updateOverwrite(message.channel.guild.roles.everyone, {  SEND_MESSAGES: true });
      let unlocked = new Discord.MessageEmbed()
      .setTitle(":unlock: | Canale Sbloccato!")
      .addField("Moderatore:", `<@` + message.author + `>`)
      .setTimestamp()
      message.channel.send(unlocked)
    }
    }
}