const Discord = require("discord.js")
module.exports = {
	name: 'tempmute',
	description: 'muta un utente',
	onlyGuild: true,
	async execute(message, args) {
  
    if (!message.member.hasPermission("MANAGE_ROLES")) {
      var minutes = args[2]
      let noperms = new Discord.MessageEmbed()
      .setTitle(":x: | Permessi Mancanti")
      .setDescription("Per utilizzare questo comando necessiti del permesso \"GESTISCI RUOLI\"")
      .setColor("RED")
      message.channel.send(noperms);
      }
      var utente = message.mentions.members.first();
      var messageArray = message.content.split(' ');
		var messageargs = messageArray.slice(3);
		var azione = messageargs.join(' ');
      var ruolo = message.guild.roles.cache.find(role => role.name == "Mutato (Raven Bot)");
      if (!utente) {
        let noutente = new Discord.MessageEmbed()
        .setTitle(":x: | Inserisci un utente")
        .setDescription("Perfavore inserisci un utente da mutare")
        .setColor("RED")
        message.reply(noutente)
      if (!ruolo) {
        ruolo = await message.guild.roles.create ({
          data: {
            name: "Mutato (Raven Bot)",
            position: 1
          }
        })
        message.guild.channels.cache.forEach((canale) => {
        canale.updateOverwrite(ruolo, {
          SEND_MESSAGES: false,
          ADD_REACTIONS: false,
          SPEAK: false 
        })
      })
      }
      }
      ruolo = message.guild.roles.cache.find(role => role.name == "Mutato (Raven Bot)")
      utente.roles.add(ruolo)
        if (!azione) {
          let noazione = new Discord.MessageEmbed()
          .setTitle(":x: | Inserisci una motivazione")
          .setColor("RED")
          message.channel.send(noazione)
        } else {
          if (azione) {
           let mutatomsg = new Discord.MessageEmbed()
          .setTitle("<:RvE_verifica:819507152896917544> | Utente mutato")
          .addField("Moderatore:", `<@${message.author.id}>`)
          .addField("Motivazione:", azione)
          .addField("Utente:", utente)
          .setTimestamp()
          .setColor("GREEN")
        message.channel.send(mutatomsg)
          let mutatodm = new Discord.MessageEmbed()
          .setTitle("Sei stato mutato")
          .addField("Moderatore:", `<@${message.author.id}>`)
          .addField("Motivazione:", azione)
          .addField("Server:", message.guild.name)
          .setTimestamp()
          .setColor("GREEN")
          utente.send(mutatodm).then(() => {
          setTimeout(function(){
    utente.roles.remove(ruolo);
  }, minutes * 60000); 
        })
          }
        }
}
}