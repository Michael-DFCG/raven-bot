const Discord = require('discord.js')
module.exports = {
	name: 'lock',
	description: 'Blocca un canale',
	onlyGuild: true,
	async execute(message, args) {
if (!message.member.hasPermission('MANAGE_CHANNELS')) { 
        let nopermessi = new Discord.MessageEmbed()
        .setDescription(":x: | Hai bisogno del permesso \"GESTISCI CANALI\" per usare questo comando")
        .setColor("RED")
        message.channel.send(nopermessi)
        } else {
      message.channel.updateOverwrite(message.channel.guild.roles.everyone, {  SEND_MESSAGES: false });
      let locked = new Discord.MessageEmbed()
      .setTitle(":lock: | Canale Bloccato")
      .addField("Moderatore:", `<@` + message.author + `>`)
      .setTimestamp()
      message.channel.send(locked)
    }
  }
}