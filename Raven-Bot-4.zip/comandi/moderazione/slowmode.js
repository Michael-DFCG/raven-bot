const Discord = require("discord.js");

module.exports = {
  name: "slowmode",
  async execute(message, args, client) {
    let slowtime = args.slice(0).join(" ");
    if(!message.member.hasPermission('MANAGE_GUILD')) {
      const noperm = new Discord.MessageEmbed()
        .setColor("RED")
        .setDescription("\\❌| Non hai i permessi necessari")
        message.channel.send(noperm);
    } else if (isNaN(args[0])) {
      const nonèunNumero = new Discord.MessageEmbed()
        .setColor("RED")
        .setDescription("\\❌| Quella è una lettera, non un numero!");
      return message.channel.send(nonèunNumero);
    } else if (args[0] >= 21601){
        const nonPuoi = new Discord.MessageEmbed()
        .setColor('RED')
        .setDescription(`\\❌| Non posso superare le 6h per lo Slowmode!`)
        return message.channel.send(nonPuoi)
    } else if (args[0] <= -1){
        const nonPuoi = new Discord.MessageEmbed()
        .setColor('RED')
        .setDescription(`\\❌| Non posso diminuire lo Slowmode sotto i 0 secondi!`)
        return message.channel.send(nonPuoi)
    } else {

    message.channel.setRateLimitPerUser(slowtime);
    const Successo = new Discord.MessageEmbed()
      .setColor("GREEN")
      .setDescription(
        `\\✅ | La slowmode è stata impostata su ${slowtime} secondi con successo!`
      );
    message.channel.send(Successo);
  }
  },
};

