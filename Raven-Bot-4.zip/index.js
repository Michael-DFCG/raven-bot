
const express = require('express');

const app = express();

app.get('/', (req, res) => {
  res.send('Hello Express app!')
});

app.listen(3000, () => {
  console.log('server started');
});
// handling!
const config = require("./config.json");
const Discord = require('discord.js');
const client = new Discord.Client();
const disbut = require('discord-buttons');
disbut(client);
const fs = require('fs');
client.commands = new Discord.Collection();
var prefix = '.';
const guilds = require('./guilds.json')
// canvas non servono li avevo messi io ieri 
const xpfile = require('./xp.json')
//và devo fare il set prefix ora
const mongoose = require('mongoose')
mongoose.connect(`mongodb+srv://d4rk:${process.env.dbpass}@cluster0.cfvic.mongodb.net/Collection`, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
}).then(console.log(`Sono Conesso Al Databese!`))

      

client.on('message', message => {
	if (message.content === `${prefix}messaggi`) {
		var utente;
		if (message.mentions.users.first()) {
			utente = message.mentions.users.first();
		} else {
			utente = message.author;
		}
		// If the author is NOT a bot...
		if (!utente.bot) {
			// If the guild isn't in the JSON file yet, set it up.
			if (!guilds[message.guild.id])
				guilds[message.guild.id] = { messageCount: 1 };
			// Otherwise, add one to the guild's message count.
			else guilds[message.guild.id].messageCount++;

			// Write the data back to the JSON file, logging any errors to the console.
			try {
				fs.writeFileSync('./guilds.json', JSON.stringify(guilds));

				const messageCount = guilds[message.guild.id].messageCount;
				const embed = new Discord.MessageEmbed()
					.setTitle('Messaggi di ' + utente.tag)
					.setDescription(
						'<@' + utente + '> ha inviato ' + messageCount + ' messaggi!'
					);
				// Send the message count in a message. The template literal (${}) adds an 's' if needed.
				message.channel.send(embed);
			} catch (err) {
				console.error(err);
			}
		}
	}
});

client.on('message', message => {
	// checks if the message author is afk
	var db = require('quick.db');
	if (db.has(message.author.id + '.afk')) {
		message.member.setNickname(`${message.author.username}`);
		message.reply("Oh eccoti! Sei uscito dalla modalità afk");
		db.delete(message.author.id + '.afk');
		db.delete(message.author.id + '.messageafk');
	}
	if (message.content.includes('.afk')) {
		var messageArray = message.content.split(' ');
		var messageargs = messageArray.slice(1);
		var reason = messageargs.join(' ');
		if (!reason) {
			message.channel.send(message.author.tag + ', è afk AFK: AFK');
		} else {
			message.channel.send(message.author.tag + ', è afk AFK: ' + reason);
		}

		message.member
			.setNickname(`[AFK] ${message.member.nickname}`)
			.catch(error => message.channel.send('Non ho potuto cambiare nicknane.'));
		// then here you use the database :
		db.set(message.author.id + '.afk', 'true');
		db.set(
			message.author.id + '.messageafk',
			message.content.split(' ').slice(2)
		);

		// I made .slice(2) so that in the message array it also delete the command and the "start-afk"
	}
	if (message.content.includes('.no-afk')) {
		message.member
			.setNickname('')
			.catch(error => message.channel.send('Non ho potuto cambiare nickname.'));
		// Here you delete it
		db.delete(message.author.id + '.afk');
		db.delete(message.author.id + '.messageafk');
	}
});

client.on('message', message => {
	// If one of the mentions is the user
	var db = require('quick.db');
	message.mentions.users.forEach(user => {
		if (db.has(user.id + '.afk'))
			message.reply("l'utente" + user.tag + ' è AFK!');
	});
});

client.on('clickButton', async button => {
	try {
		if (button.id == `ciao`) {
			button.channel.send('ciao!');
		}
	} catch (err) {
		message.channel.send('BASTAAAA');
	}
});
client.on('ready', () => {
	console.log('Bot is now connected');
	let clab = new Discord.MessageEmbed()
		.setColor('GREEN')
		.setTitle('Bot Online')
		.setDescription('Il bot è stato avviato correttamente');
	client.channels.cache
		.find(channel => channel.name === `┃👍║stato-bot`).
		send(clab); })
;


client.on('ready', () => {
	let totalUsers = client.guilds.cache.reduce(
		(acc, value) => acc + value.memberCount,
		0
	);
	let totalS = client.guilds.cache.size;
	var activities = [
			` | ${totalS} servers`,
			` | ${totalUsers} utenti`,
			` | v1.1.8`
		],
		i = 0;
	setInterval(
		() =>
			client.user.setActivity(
				`Spotify | ${prefix}help${activities[i++ % activities.length]}`,
				{ type: 'LISTENING' }
			),
		7000
	);
});

const commandFolders = fs.readdirSync('./comandi');

for (const folder of commandFolders) {
	const commandFiles = fs
		.readdirSync(`./comandi/${folder}`)
		.filter(file => file.endsWith('.js'));
	for (const file of commandFiles) {
		const command = require(`./comandi/${folder}/${file}`);
		client.commands.set(command.name, command);
		
		console.log('[CMD]', file);
		
}
}


const eventFiles = fs
	.readdirSync('./events')
	.filter(file => file.endsWith('.js'));

for (const file of eventFiles) {
	const event = require(`./events/${file}`);
	if (event.once) {
		client.once(event.name, (...args) => event.execute(...args, client));
	} else {
		client.on(event.name, (...args) => event.execute(...args, client));
	}
}



const escapeRegex = str => str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');


client.on('message', message => {
  if (!message.content.startsWith(prefix) || message.author.bot) return;
  
	const args = message.content.slice(prefix.length || "<@!863020585838837771>").trim().split(/ +/);
	const command = args.shift().toLowerCase();

	if (!client.commands.has(command)) return
	try { 
		client.commands.get(command).execute(message, args);
	} catch (error) {
	  let errore = new Discord.MessageEmbed()
.setTitle(":x: | errore")
.setDescription("i developers del bot hanno scritto qualcosa di sbagliato, risolveranno al più presto\n**Errore**\n"+error)
		console.error(error);
		message.reply(errore)
	}
})
client.on('guildCreate', async guild => {
	let newGuuld = client.channels.cache.get('869247621133369404');
	// Returns <Channel>

	let channeltoSend;
	guild.channels.cache.forEach(channel => {
		if (
			channel.type === 'text' &&
			!channeltoSend &&
			channel.permissionsFor(guild.me).has('SEND_MESSAGES')
		)
			channeltoSend = channel;
	});
	const Invite = await guild.createInvite({
		maxAge: 0,
		unique: true,
		reason: 'Comunicazione server allo staff di Raven Empire (discord.gg/rve).'
	});
	let sonoentrato = new Discord.MessageEmbed()
		.setTitle(
			`<a:RvE_gattocuore:853011798466887720> | Grazie per avermi aggiunto`
		)
		.setDescription(
			'Grazie per avermi aggiunto!' +
				`\nTi ricordo che il mio prefisso è ` +
				'`.`'
		)
		.setColor('RANDOM');
	let GG = new Discord.MessageEmbed()
		.setTitle(
			`<a:RvE_gattocuore:853011798466887720> | Grazie per avermi aggiunto`
		)
		.setDescription('Grazie per avermi aggiunto!')
		.setFooter(Invite)
		.setColor('RANDOM');
	channeltoSend.send(sonoentrato); //NON TOCCARE
	newGuuld.send(GG);
});

const PBapi = require('prime-bots.js');
const PrimeBot = new PBapi('APIToken.gteicak4qqc.iu62twzgf2b', client);
// Questo è l'evento che si attiva quando lo script si connette ai server dell'api:
PrimeBot.on('ready', () => {
	console.log('[PB] Server di PrimeBots collegati!');
});

PrimeBot.on('vote', vote => {
	console.log(vote.id + ' ha appena votato il bot!');
	var channeltoSend = client.channels.cache.get('869247621133369404');

	let sonoentrato = new Discord.MessageEmbed()
		.setTitle(
			`<a:RvE_gattocuore:853011798466887720> | <@${vote.id}> Mi ha appena votato su PrimeBots`
		)
		.setDescription('Grazie Mille!')
		.setColor('GREEN');
	channeltoSend.send(sonoentrato);
});

const { GiveawaysManager } = require('discord-giveaways');
// Create a new instance of the manager class
const manager = new GiveawaysManager(client, {
	storage: './giveaways.json',
	updateCountdownEvery: 10000,
	default: {
		botsCanWin: false,
		exemptPermissions: ['MANAGE_MESSAGES', 'ADMINISTRATOR'],
		embedColor: '#FF0000',
		embedColorEnd: '#000000',
		reaction: '🎉'
 	
  }
})
// We now have a giveawaysManager property to access the manager everywhere!
client.giveawaysManager = manager;


client.login(process.env.token);



const Database = require('@replit/database');
const db = new Database(console.log('[DB] connesso!'));



